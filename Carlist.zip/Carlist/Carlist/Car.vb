﻿'Author: Sebastian Anderson
'Filename: Car.vb
'Date created: March 13, 2020
'Date last modified: March 15, 2020
'Description: This is a class is a car object is used as part of Lab 4 for NetD 2202.

Option Strict On

Public Class Car

#Region "Variable Declaration"

    ''' <summary>
    ''' This section is for the decloration of variables throughout the program
    ''' </summary>
    Private Shared carCount As Integer = 0
    Private carID As Integer = 0
    Private carMake As String = ""
    Private carModel As String = ""
    Private carYear As Integer = 0
    Private carPrice As Decimal = 0.0D
    Private carNew As Boolean = True

#End Region

#Region "Constructors"
    ''' <summary>
    ''' This constructor incroments car count and changes the value of car ID
    ''' </summary>
    Friend Sub New()
        carCount += 1
        carID = carCount

    End Sub


    ''' <summary>
    ''' Sets the private varables according to values that are being passed into them.
    ''' </summary>
    ''' <param name="makeValue">This represents the make of the car</param>
    ''' <param name="modelValue">This represents the model of the car</param>
    ''' <param name="yearValue">This represents the year the car was made</param>
    ''' <param name="priceValue">This represents the price of the car</param>
    ''' <param name="isNew">
    ''' This value is represents weather a car is or is not new with true being new and false being used.</param>
    Friend Sub New(makeValue As String, modelValue As String, yearValue As Integer, priceValue As Decimal, isNew As Boolean)
        Me.New()
        carMake = makeValue
        carModel = modelValue
        carYear = yearValue
        carPrice = priceValue
        carNew = isNew

    End Sub

#End Region

#Region "Properties"


    ''' <summary>
    ''' Returns the number of cars
    ''' </summary>
    ''' <returns>The number of cars</returns>
    Private Shared ReadOnly Property Count() As Integer
        Get
            Return carCount
        End Get
    End Property


    ''' <summary>
    ''' Returns the Identification number of a car
    ''' </summary>
    ''' <returns>the cars Identification number of a car</returns>
    Public ReadOnly Property Id() As Integer
        Get
            Return carID
        End Get
    End Property


    ''' <summary>
    ''' retrieves and sets the manufacturer of a car
    ''' </summary>
    ''' <returns>a cars manufactuerer</returns>
    Public Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property


    ''' <summary>
    ''' retrieves and sets the model of a car
    ''' </summary>
    ''' <returns>a cars model</returns>
    Public Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property

    ''' <summary>
    ''' retrieves and sets the year of a car
    ''' </summary>
    ''' <returns>a cars year</returns>
    Public Property Year() As Integer
        Get
            Return carYear
        End Get
        Set(value As Integer)
            carYear = value
        End Set
    End Property

    ''' <summary>
    ''' retrieves and sets the price of a car
    ''' </summary>
    ''' <returns>a cars price</returns>
    Public Property Price() As Decimal
        Get
            Return carPrice
        End Get
        Set(value As Decimal)
            carPrice = value
        End Set
    End Property

    ''' <summary>
    ''' Find out if the car is new or used
    ''' </summary>
    ''' <returns>True is new and False is old</returns>
    Public Property NewCar() As Boolean
        Get
            Return carNew
        End Get
        Set(value As Boolean)
            carNew = value
        End Set
    End Property
#End Region

#Region "Method"

    ''' <summary>
    ''' Returns a string that holds the discription of the car based on the varables entered above
    ''' </summary>
    ''' <returns></returns>
    Friend Function GetCarData() As String
        If carNew = True Then
            Return "New " & carYear & " " & carMake & " " & carModel & " Priced at " & carPrice.ToString("C")
        Else
            Return "Used " & carYear & " " & carMake & " " & carModel & " Priced at " & carPrice.ToString("C")
        End If

    End Function

#End Region

End Class
