﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmcarList
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbltitleMake = New System.Windows.Forms.Label()
        Me.lbltitleModel = New System.Windows.Forms.Label()
        Me.lbltitleYear = New System.Windows.Forms.Label()
        Me.lbltitlePrice = New System.Windows.Forms.Label()
        Me.chkNew = New System.Windows.Forms.CheckBox()
        Me.cboMake = New System.Windows.Forms.ComboBox()
        Me.nudYear = New System.Windows.Forms.NumericUpDown()
        Me.tbModel = New System.Windows.Forms.TextBox()
        Me.tbPrice = New System.Windows.Forms.TextBox()
        Me.lvwCarList = New System.Windows.Forms.ListView()
        Me.colNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttpcarList = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.nudYear, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbltitleMake
        '
        Me.lbltitleMake.AutoSize = True
        Me.lbltitleMake.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitleMake.ForeColor = System.Drawing.Color.Yellow
        Me.lbltitleMake.Location = New System.Drawing.Point(95, 9)
        Me.lbltitleMake.Name = "lbltitleMake"
        Me.lbltitleMake.Size = New System.Drawing.Size(52, 20)
        Me.lbltitleMake.TabIndex = 0
        Me.lbltitleMake.Text = "Make:"
        '
        'lbltitleModel
        '
        Me.lbltitleModel.AutoSize = True
        Me.lbltitleModel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitleModel.ForeColor = System.Drawing.Color.Yellow
        Me.lbltitleModel.Location = New System.Drawing.Point(91, 40)
        Me.lbltitleModel.Name = "lbltitleModel"
        Me.lbltitleModel.Size = New System.Drawing.Size(56, 20)
        Me.lbltitleModel.TabIndex = 2
        Me.lbltitleModel.Text = "Model:"
        '
        'lbltitleYear
        '
        Me.lbltitleYear.AutoSize = True
        Me.lbltitleYear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitleYear.ForeColor = System.Drawing.Color.Yellow
        Me.lbltitleYear.Location = New System.Drawing.Point(100, 71)
        Me.lbltitleYear.Name = "lbltitleYear"
        Me.lbltitleYear.Size = New System.Drawing.Size(47, 20)
        Me.lbltitleYear.TabIndex = 4
        Me.lbltitleYear.Text = "Year:"
        '
        'lbltitlePrice
        '
        Me.lbltitlePrice.AutoSize = True
        Me.lbltitlePrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitlePrice.ForeColor = System.Drawing.Color.Yellow
        Me.lbltitlePrice.Location = New System.Drawing.Point(99, 102)
        Me.lbltitlePrice.Name = "lbltitlePrice"
        Me.lbltitlePrice.Size = New System.Drawing.Size(48, 20)
        Me.lbltitlePrice.TabIndex = 6
        Me.lbltitlePrice.Text = "Price:"
        '
        'chkNew
        '
        Me.chkNew.AutoSize = True
        Me.chkNew.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkNew.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkNew.ForeColor = System.Drawing.Color.Yellow
        Me.chkNew.Location = New System.Drawing.Point(103, 125)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(63, 24)
        Me.chkNew.TabIndex = 8
        Me.chkNew.Text = "New:"
        Me.ttpcarList.SetToolTip(Me.chkNew, "Check this box if your car is new")
        Me.chkNew.UseVisualStyleBackColor = True
        '
        'cboMake
        '
        Me.cboMake.BackColor = System.Drawing.Color.Aquamarine
        Me.cboMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMake.ForeColor = System.Drawing.Color.DarkCyan
        Me.cboMake.FormattingEnabled = True
        Me.cboMake.Items.AddRange(New Object() {"Ford", "Lamborghini", "Ram", "Subaru", "Dodge", "Toytota", "Nissan", "Porsche", "Bugatti"})
        Me.cboMake.Location = New System.Drawing.Point(153, 12)
        Me.cboMake.Name = "cboMake"
        Me.cboMake.Size = New System.Drawing.Size(121, 21)
        Me.cboMake.TabIndex = 1
        Me.ttpcarList.SetToolTip(Me.cboMake, "This is where you select the make of the car.")
        '
        'nudYear
        '
        Me.nudYear.BackColor = System.Drawing.Color.Aquamarine
        Me.nudYear.ForeColor = System.Drawing.Color.DarkCyan
        Me.nudYear.Location = New System.Drawing.Point(153, 73)
        Me.nudYear.Maximum = New Decimal(New Integer() {2020, 0, 0, 0})
        Me.nudYear.Minimum = New Decimal(New Integer() {1920, 0, 0, 0})
        Me.nudYear.Name = "nudYear"
        Me.nudYear.Size = New System.Drawing.Size(121, 20)
        Me.nudYear.TabIndex = 5
        Me.ttpcarList.SetToolTip(Me.nudYear, "This is where you select the year the car was made.")
        Me.nudYear.Value = New Decimal(New Integer() {1920, 0, 0, 0})
        '
        'tbModel
        '
        Me.tbModel.BackColor = System.Drawing.Color.Aquamarine
        Me.tbModel.ForeColor = System.Drawing.Color.DarkCyan
        Me.tbModel.Location = New System.Drawing.Point(153, 43)
        Me.tbModel.Name = "tbModel"
        Me.tbModel.Size = New System.Drawing.Size(121, 20)
        Me.tbModel.TabIndex = 3
        Me.ttpcarList.SetToolTip(Me.tbModel, "This is where you put the model of the car.")
        '
        'tbPrice
        '
        Me.tbPrice.BackColor = System.Drawing.Color.Aquamarine
        Me.tbPrice.ForeColor = System.Drawing.Color.DarkCyan
        Me.tbPrice.Location = New System.Drawing.Point(153, 103)
        Me.tbPrice.Name = "tbPrice"
        Me.tbPrice.Size = New System.Drawing.Size(121, 20)
        Me.tbPrice.TabIndex = 7
        Me.ttpcarList.SetToolTip(Me.tbPrice, "This is where you put the price of the car.")
        '
        'lvwCarList
        '
        Me.lvwCarList.BackColor = System.Drawing.Color.Aquamarine
        Me.lvwCarList.CheckBoxes = True
        Me.lvwCarList.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNew, Me.colID, Me.colMake, Me.colModel, Me.colYear, Me.colPrice})
        Me.lvwCarList.ForeColor = System.Drawing.Color.DarkCyan
        Me.lvwCarList.FullRowSelect = True
        Me.lvwCarList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwCarList.HideSelection = False
        Me.lvwCarList.Location = New System.Drawing.Point(6, 162)
        Me.lvwCarList.MultiSelect = False
        Me.lvwCarList.Name = "lvwCarList"
        Me.lvwCarList.Size = New System.Drawing.Size(353, 212)
        Me.lvwCarList.TabIndex = 9
        Me.ttpcarList.SetToolTip(Me.lvwCarList, "Displays a list of previously entered cars.")
        Me.lvwCarList.UseCompatibleStateImageBehavior = False
        Me.lvwCarList.View = System.Windows.Forms.View.Details
        '
        'colNew
        '
        Me.colNew.Text = "New or Used"
        Me.colNew.Width = 75
        '
        'colID
        '
        Me.colID.Text = "ID"
        Me.colID.Width = 50
        '
        'colMake
        '
        Me.colMake.Text = "Make"
        Me.colMake.Width = 65
        '
        'colModel
        '
        Me.colModel.Text = "Model"
        Me.colModel.Width = 66
        '
        'colYear
        '
        Me.colYear.Text = "Year"
        Me.colYear.Width = 36
        '
        'colPrice
        '
        Me.colPrice.Text = "Price"
        Me.colPrice.Width = 58
        '
        'lblOutput
        '
        Me.lblOutput.BackColor = System.Drawing.SystemColors.HotTrack
        Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutput.ForeColor = System.Drawing.Color.Yellow
        Me.lblOutput.Location = New System.Drawing.Point(6, 389)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(353, 76)
        Me.lblOutput.TabIndex = 10
        Me.ttpcarList.SetToolTip(Me.lblOutput, "Displays error messages")
        '
        'btnEnter
        '
        Me.btnEnter.BackColor = System.Drawing.Color.Orange
        Me.btnEnter.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnter.ForeColor = System.Drawing.Color.Navy
        Me.btnEnter.Location = New System.Drawing.Point(6, 478)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 26)
        Me.btnEnter.TabIndex = 11
        Me.btnEnter.Text = "Enter"
        Me.ttpcarList.SetToolTip(Me.btnEnter, "This button allows for you to enter values into the large aqua text  box above. y" &
        "ou can activate this button by pressing it or pressing enter.")
        Me.btnEnter.UseVisualStyleBackColor = False
        '
        'btnReset
        '
        Me.btnReset.BackColor = System.Drawing.Color.Magenta
        Me.btnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.Navy
        Me.btnReset.Location = New System.Drawing.Point(284, 478)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 26)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "&Reset"
        Me.ttpcarList.SetToolTip(Me.btnReset, "This resets all the boxes for user input when pressed or if you press alt + r at " &
        "the same time.")
        Me.btnReset.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.LawnGreen
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Navy
        Me.btnExit.Location = New System.Drawing.Point(153, 478)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 26)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Exit"
        Me.ttpcarList.SetToolTip(Me.btnExit, "This button exits the program when pressed. You can also press escape to exit the" &
        " program.")
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'frmcarList
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(365, 510)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.lvwCarList)
        Me.Controls.Add(Me.tbPrice)
        Me.Controls.Add(Me.tbModel)
        Me.Controls.Add(Me.nudYear)
        Me.Controls.Add(Me.cboMake)
        Me.Controls.Add(Me.chkNew)
        Me.Controls.Add(Me.lbltitlePrice)
        Me.Controls.Add(Me.lbltitleYear)
        Me.Controls.Add(Me.lbltitleModel)
        Me.Controls.Add(Me.lbltitleMake)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmcarList"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car List"
        CType(Me.nudYear, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbltitleMake As Label
    Friend WithEvents lbltitleModel As Label
    Friend WithEvents lbltitleYear As Label
    Friend WithEvents lbltitlePrice As Label
    Friend WithEvents chkNew As CheckBox
    Friend WithEvents cboMake As ComboBox
    Friend WithEvents nudYear As NumericUpDown
    Friend WithEvents tbModel As TextBox
    Friend WithEvents tbPrice As TextBox
    Friend WithEvents lvwCarList As ListView
    Friend WithEvents lblOutput As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents colNew As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colMake As ColumnHeader
    Friend WithEvents colModel As ColumnHeader
    Friend WithEvents colYear As ColumnHeader
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents ttpcarList As ToolTip
End Class
