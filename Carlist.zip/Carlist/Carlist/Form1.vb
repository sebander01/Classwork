﻿'Author: Sebastian Anderson
'Filename: Carlist.vb
'Date created: March 15th, 2020
'Description: In this lab we are using a class to return various peices of information about cars for the user to see.

Option Strict On

Public Class frmcarList

#Region "Variable Declarion"
    ''' <summary>
    ''' Declaration of variables to be used through out the program
    ''' </summary>
    Dim carObject As Car
    Dim currentlySelected As Boolean = False
    Dim addingToListView As Boolean = False
    Dim carList As New List(Of Car)
#End Region


#Region "Events"
    ''' <summary>
    ''' This controls the exit button and allows for the form to close if the exit button is pressed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' Resets the program to default
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnreset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        setDefaults()
    End Sub



    Private Sub btnenter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        If IsValid() = True Then

            'If the object dosen't already exist make the object
            If Not currentlySelected = True Then
                carObject = New Car(cboMake.Text, tbModel.Text, Convert.ToInt32(nudYear.Text), Convert.ToDecimal(tbPrice.Text), Convert.ToBoolean(chkNew.Checked))
                carList.Add(carObject)
                lblOutput.Text = ""
                'If it does then send send the object through to the class
            ElseIf carObject.Id > 0 Then
                carObject.Make = cboMake.Text
                carObject.Model = tbModel.Text
                carObject.NewCar = chkNew.Checked
                carObject.Price = Convert.ToDecimal(tbPrice.Text)
                carObject.Year = Convert.ToInt32(nudYear)
                lblOutput.Text = ""
            End If
        End If
        setDefaults()
    End Sub
#End Region



#Region "Set Defaults"

    ''' <summary>
    ''' Sets the defaults for the program
    ''' </summary>
    Sub setDefaults()
        populateList()
        tbModel.Text = ""
        tbPrice.Text = ""
        chkNew.Checked = False
        nudYear.Value = nudYear.Minimum
        cboMake.SelectedIndex = -1
    End Sub
#End Region

#Region "Validation"
    ''' <summary>
    ''' This block of code validates that the input is infact correct
    ''' </summary>
    ''' <returns></returns>
    Private Function IsValid() As Boolean
        Dim num As Decimal = 0.0D

        'If model text box has nothing in it don't allow the program to continue
        If tbModel.Text = "" Then
            lblOutput.Text = "You must fill out all feilds of data before the car can be added to inventory. Please make sure that the car has a model selected."
            Return False
            'If price is not a number or is text do not allow it
        ElseIf Decimal.TryParse(tbPrice.Text, num) = False Then
            lblOutput.Text = "Price will only accept numaric values. Text values will not be accepted and empty values will not be accepted."
            Return False
            'If the make is empty dosen't allow it
        ElseIf cboMake.Text = "" Then
            lblOutput.Text = "You must fill out all feilds of data before the car can be added to inventory. Please make sure that the car make has been filled in."
            Return False
            'If none of these apply it's true
        Else
            Return True
        End If
    End Function
#End Region

#Region "Selection stuff"
    ''' <summary>
    ''' Checks if the item in the list has been already selected if it has been if dosen't allow you to enter any more data aslong as you are still selecting the item
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub lvwcarList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCarList.SelectedIndexChanged

        If lvwCarList.SelectedIndices.Count = 1 Then

            carObject = carList(lvwCarList.SelectedIndices(0))
            currentlySelected = True

            cboMake.Text = carObject.Make
            tbModel.Text = carObject.Model
            nudYear.Value = carObject.Year
            tbPrice.Text = Convert.ToString(carObject.Price)
            chkNew.Checked = carObject.NewCar
            cboMake.Enabled = False
            tbModel.Enabled = False
            nudYear.Enabled = False
            tbPrice.Enabled = False
            currentlySelected = False

        Else
            currentlySelected = False
            cboMake.Enabled = True
            tbModel.Enabled = True
            nudYear.Enabled = True
            tbPrice.Enabled = True
        End If
    End Sub

    ''' <summary>
    ''' Stops you from checking or unchecking the new and used box
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub lvwcarList_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwCarList.ItemCheck

        ' If we're not currently adding characters to the list
        If Not addingToListView Then

            ' Maintain the old checkbox value
            e.NewValue = e.CurrentValue

        End If

    End Sub
#End Region
#Region "List populating"

    ''' <summary>
    ''' Populates the list and in doing so creates items in the listview.
    ''' </summary>
    Sub populateList()

        lvwCarList.Items.Clear()

        For I As Integer = 0 To carList.Count - 1
            Dim carItems As New ListViewItem()

            carItems.SubItems.Add(carList(I).Id.ToString())
            carItems.SubItems.Add(carList(I).Make)
            carItems.SubItems.Add(carList(I).Model)
            carItems.SubItems.Add(carList(I).Year.ToString)
            carItems.SubItems.Add(carList(I).Price.ToString)
            carItems.Checked = carList(I).NewCar

            addingToListView = True
            lvwCarList.Items.Add(carItems)
            addingToListView = False
        Next
    End Sub
#End Region
End Class
