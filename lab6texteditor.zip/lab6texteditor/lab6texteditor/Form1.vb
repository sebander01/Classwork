﻿'Sebastian Anderson
'100717369
'Data April 3, 2020
'Description: In this lab we are creating a very basic text editor able to both save and open files as you would expect a text editor to do.

Option Strict On
Imports System.IO
Public Class frmTextEditor
#Region "Declaration"
    ''' <summary>
    ''' This is where I declared varables that were used throughout the program and needed to be called from multiple different classes.
    ''' </summary>
    Dim isFileOpen As Boolean = False
    Dim openFilePath As String = String.Empty
    Dim saveFile As FileStream
    Dim fileWriter As StreamWriter
#End Region

#Region "Help Tab"
    ''' <summary>
    ''' This programs the about tab and makes it tell you about the form when it opens.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuHelpAbout_Click(sender As Object, e As EventArgs) Handles mmuHelpAbout.Click
        MessageBox.Show("lab6texteditor" & vbCrLf & vbCrLf & "By Sebastian Anderson" & vbCrLf & vbCrLf & "April 3, 2020")

    End Sub
#End Region
#Region "File Tab"

    ''' <summary>
    ''' This exits the program.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuFileExit_Click(sender As Object, e As EventArgs) Handles mmuFileExit.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' This creates a new blank document in the text editor.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuFileNew_Click(sender As Object, e As EventArgs) Handles mmuFileNew.Click
        tbTextEditor.Clear()
        isFileOpen = False
        openFilePath = String.Empty
    End Sub

    ''' <summary>
    ''' Opens a saved file.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuFileOpen_Click(sender As Object, e As EventArgs) Handles mmuFileOpen.Click

        Dim openFile As FileStream
        Dim fileReader As StreamReader

        If opdOpen.ShowDialog() = DialogResult.OK Then
            openFilePath = opdOpen.FileName
            isFileOpen = True

            openFile = New FileStream(openFilePath, FileMode.Open, FileAccess.Read)
            fileReader = New StreamReader(openFile)

            tbTextEditor.Text = fileReader.ReadToEnd

            fileReader.Close()

        End If
    End Sub

    ''' <summary>
    ''' Saves the file.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuFileSave_Click(sender As Object, e As EventArgs) Handles mmuFileSave.Click
        'If there is no file path treat the save as a save as and create a file path
        If openFilePath = String.Empty Then
            'This varable is used in every single save function and procedure but for whatever reason it had to be in the class it was being used in and would not work as a global varable I am sure this is just a glitch.
            'But I wanted you to know there is a method to my madness.
            Dim saveData As SaveFileDialog = svdSave
            'Sets values as a default for files being created in this text editor and allows you to pick .txt as a format without having to type .txt. This also insures that files saved without a prefix will still
            'Be usable by the text editor that created them and will contain information put into them.
            saveData.FileName = "File1.txt"
            saveData.Filter = "Text File (*.txt)|*.txt"
            If saveData.ShowDialog() = DialogResult.OK Then
                Save()

            End If
            'If the file already has a file path just continue on with that file path
        Else
            Dim saveData As SaveFileDialog = svdSave
            Save()
            MessageBox.Show("Saved")


        End If
    End Sub

    ''' <summary>
    ''' Allows you to save as
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuSaveAs_Click(sender As Object, e As EventArgs) Handles mmuSaveAs.Click
        Dim saveData As SaveFileDialog = svdSave
        saveData.FileName = "File1.txt"
        saveData.Filter = "Text File (*.txt)|*.txt"
        If saveData.ShowDialog() = DialogResult.OK Then
            Save()

        End If
    End Sub
#End Region
#Region "Edit Tab"

    ''' <summary>
    ''' This is the copy button
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuEditCopy_Click(sender As Object, e As EventArgs) Handles mmuEditCopy.Click
        copy()
    End Sub

    ''' <summary>
    ''' This is the paste button
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuEditPaste_Click(sender As Object, e As EventArgs) Handles mmuEditPaste.Click
        paste()
    End Sub

    ''' <summary>
    ''' This is the cut button
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub mmuCut_Click(sender As Object, e As EventArgs) Handles mmuCut.Click
        cut()
    End Sub
#End Region
#Region "Subs"
    ''' <summary>
    ''' A sub for saving the program
    ''' </summary>
    Sub Save()
        ''I got a little help from this video https://www.youtube.com/watch?v=zrma1jQi0FM here but I just used it as a refrence point to set defaults for save as and to figure out how I should do the
        ''fileWriter.Write(tbTextEditor) and fileWriter.Flush() lines.
        'Most of this I got from adapting the open button.
        openFilePath = svdSave.FileName
        isFileOpen = True


        saveFile = New FileStream(openFilePath, FileMode.Create, FileAccess.Write)
        fileWriter = New StreamWriter(saveFile)

        fileWriter.Write(tbTextEditor)
        fileWriter.Flush()

        fileWriter.Close()
    End Sub

    ''' <summary>
    ''' Adds controls for copying pasting and cuting text inside the text editor with key presses.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub tbTextEditor_TextChanged(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        'I got a little help from this website here https://www.experts-exchange.com/questions/21350703/How-do-I-trap-on-Ctrl-C-Ctrl-V-and-Ctrl-X-using-the-KeyPress-Event-in-VB-NET.html
        Select Case e.KeyCode
            'IF control x is plressed cut
            Case Keys.Control And Keys.X
                cut()
            'If control c is pressed copy
            Case Keys.Control And Keys.C
                copy()
            'If control v is pressed paste
            Case Keys.Control And Keys.V
                paste()
        End Select
    End Sub

    ''' <summary>
    ''' Sub to copy text and add it to your clip board
    ''' </summary>
    Sub copy()
        My.Computer.Clipboard.SetText(tbTextEditor.SelectedText)
    End Sub

    ''' <summary>
    ''' Sub for cutting text out of the program and adding it to your clip board
    ''' </summary>
    Sub cut()
        My.Computer.Clipboard.SetText(tbTextEditor.SelectedText)
        tbTextEditor.SelectedText = ""
    End Sub

    Sub paste()
        'My.Computer.Clipboard.GetText(CType(tbTextEditor.SelectionStart, TextDataFormat))
        tbTextEditor.Paste()
    End Sub

#End Region
End Class
