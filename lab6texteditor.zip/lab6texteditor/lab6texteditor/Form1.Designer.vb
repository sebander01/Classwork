﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTextEditor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.opdOpen = New System.Windows.Forms.OpenFileDialog()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mmuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuFileNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuSaveAs = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuFileOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuEditCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuEditPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuCut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mmuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.ttTextEditor = New System.Windows.Forms.ToolTip(Me.components)
        Me.tbTextEditor = New System.Windows.Forms.TextBox()
        Me.svdSave = New System.Windows.Forms.SaveFileDialog()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'opdOpen
        '
        Me.opdOpen.FileName = "OpenFileDialog1"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuFile, Me.mmuEdit, Me.mmuHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mmuFile
        '
        Me.mmuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuFileNew, Me.mmuSaveAs, Me.mmuFileSave, Me.mmuFileOpen, Me.mmuFileExit})
        Me.mmuFile.Name = "mmuFile"
        Me.mmuFile.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.mmuFile.Size = New System.Drawing.Size(37, 20)
        Me.mmuFile.Text = "&File"
        Me.mmuFile.ToolTipText = "This tab opens file options. Press F2 to open with a short cut."
        '
        'mmuFileNew
        '
        Me.mmuFileNew.Name = "mmuFileNew"
        Me.mmuFileNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.mmuFileNew.Size = New System.Drawing.Size(146, 22)
        Me.mmuFileNew.Text = "&New"
        Me.mmuFileNew.ToolTipText = "This creates a new blank document for you to edit by and removes the previous uns" &
    "aved text from the editor."
        '
        'mmuSaveAs
        '
        Me.mmuSaveAs.Name = "mmuSaveAs"
        Me.mmuSaveAs.Size = New System.Drawing.Size(146, 22)
        Me.mmuSaveAs.Text = "&Save As"
        '
        'mmuFileSave
        '
        Me.mmuFileSave.Name = "mmuFileSave"
        Me.mmuFileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mmuFileSave.Size = New System.Drawing.Size(146, 22)
        Me.mmuFileSave.Text = "&Save"
        Me.mmuFileSave.ToolTipText = "Saves the file currently in the text editor."
        '
        'mmuFileOpen
        '
        Me.mmuFileOpen.Name = "mmuFileOpen"
        Me.mmuFileOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mmuFileOpen.Size = New System.Drawing.Size(146, 22)
        Me.mmuFileOpen.Text = "&Open"
        Me.mmuFileOpen.ToolTipText = "This opens files that have been saved before so you you can continue working."
        '
        'mmuFileExit
        '
        Me.mmuFileExit.Name = "mmuFileExit"
        Me.mmuFileExit.Size = New System.Drawing.Size(146, 22)
        Me.mmuFileExit.Text = "&Exit"
        Me.mmuFileExit.ToolTipText = "This exits the program without saving anything in the text editor."
        '
        'mmuEdit
        '
        Me.mmuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuEditCopy, Me.mmuEditPaste, Me.mmuCut})
        Me.mmuEdit.Name = "mmuEdit"
        Me.mmuEdit.Size = New System.Drawing.Size(39, 20)
        Me.mmuEdit.Text = "&Edit"
        '
        'mmuEditCopy
        '
        Me.mmuEditCopy.Name = "mmuEditCopy"
        Me.mmuEditCopy.ShortcutKeyDisplayString = "Ctrl+C"
        Me.mmuEditCopy.Size = New System.Drawing.Size(144, 22)
        Me.mmuEditCopy.Text = "Copy"
        Me.mmuEditCopy.ToolTipText = "Copies text."
        '
        'mmuEditPaste
        '
        Me.mmuEditPaste.Name = "mmuEditPaste"
        Me.mmuEditPaste.ShortcutKeyDisplayString = "Ctrl+V"
        Me.mmuEditPaste.Size = New System.Drawing.Size(144, 22)
        Me.mmuEditPaste.Text = "Paste"
        '
        'mmuCut
        '
        Me.mmuCut.Name = "mmuCut"
        Me.mmuCut.ShortcutKeyDisplayString = "Ctrl+X"
        Me.mmuCut.Size = New System.Drawing.Size(144, 22)
        Me.mmuCut.Text = "Cut"
        Me.mmuCut.ToolTipText = "This allows you to cut text from the text editor."
        '
        'mmuHelp
        '
        Me.mmuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mmuHelpAbout})
        Me.mmuHelp.Name = "mmuHelp"
        Me.mmuHelp.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F1), System.Windows.Forms.Keys)
        Me.mmuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mmuHelp.Text = "&Help"
        Me.mmuHelp.ToolTipText = "This tabe provides you with all the help you could need with using this applicati" &
    "on. Press Ctrl+F1 for a shortcut to open this tab."
        '
        'mmuHelpAbout
        '
        Me.mmuHelpAbout.Name = "mmuHelpAbout"
        Me.mmuHelpAbout.ShortcutKeyDisplayString = "F1"
        Me.mmuHelpAbout.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.mmuHelpAbout.Size = New System.Drawing.Size(126, 22)
        Me.mmuHelpAbout.Text = "About"
        Me.mmuHelpAbout.ToolTipText = "This gives you information about the form."
        '
        'tbTextEditor
        '
        Me.tbTextEditor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tbTextEditor.Location = New System.Drawing.Point(0, 24)
        Me.tbTextEditor.Multiline = True
        Me.tbTextEditor.Name = "tbTextEditor"
        Me.tbTextEditor.Size = New System.Drawing.Size(800, 426)
        Me.tbTextEditor.TabIndex = 1
        Me.ttTextEditor.SetToolTip(Me.tbTextEditor, "This is where you type text that the text editor will interact with given various" &
        " controls.")
        '
        'frmTextEditor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.tbTextEditor)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmTextEditor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Text Editor"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents opdOpen As OpenFileDialog
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ttTextEditor As ToolTip
    Friend WithEvents tbTextEditor As TextBox
    Friend WithEvents mmuFile As ToolStripMenuItem
    Friend WithEvents mmuHelp As ToolStripMenuItem
    Friend WithEvents mmuHelpAbout As ToolStripMenuItem
    Friend WithEvents mmuFileNew As ToolStripMenuItem
    Friend WithEvents mmuFileOpen As ToolStripMenuItem
    Friend WithEvents mmuFileExit As ToolStripMenuItem
    Friend WithEvents mmuFileSave As ToolStripMenuItem
    Friend WithEvents svdSave As SaveFileDialog
    Friend WithEvents mmuSaveAs As ToolStripMenuItem
    Friend WithEvents mmuEdit As ToolStripMenuItem
    Friend WithEvents mmuEditCopy As ToolStripMenuItem
    Friend WithEvents mmuEditPaste As ToolStripMenuItem
    Friend WithEvents mmuCut As ToolStripMenuItem
End Class
